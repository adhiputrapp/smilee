<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1 class="mb-6 text-3xl font-bold border-b-2">Laporan BKU</h1>


    <div class="mb-3 w-full">

        <form action="<?php echo e(route('laporan.export')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <div class="relative mb-4 flex w-full gap-x-2">
                <h1 class="mt-3 mr-1">Bulan</h1>
                <select name="bulan" id="bulan"
                    class="block mt-1 w-1/4 border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                    <option value="">-</option>
                    <?php for($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo e(date('F', mktime(0, 0, 0, $i, 1))); ?>"><?php echo e(date('F', mktime(0, 0, 0, $i, 1))); ?></option>
                <?php endfor; ?>
                </select>
            </div>
    
            <div class="relative mb-4 flex w-full gap-x-2">
                <h1 class="mt-3">Tahun</h1>
                <select name="tahun" id="tahun"
                    class="block mt-1 w-1/4 border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                    <option value="">-</option>
                    <?php
                    $currentYear = date('Y');
                    $startYear = 2020;
                    ?>
                    <?php for($year = $currentYear; $year >= $startYear; $year--): ?>
                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
    </div>

    <div class="mb-3 w-full">
        <h1 class="mt-3">Sub Kegiatan</h1>

                <div class="relative mb-4 flex w-full gap-x-2">
                    <select name="subkegiatan_id" id="subkegiatan_id"
                        class="block mt-1 w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                        <option value="">-</option>
                        <?php $__currentLoopData = $subkegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subkegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subkegiatan->id); ?>"><?php echo e($subkegiatan->nama_sub_kegiatan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button type="submit"
                        class="inline-block rounded bg-primary px-6 pb-2 pt-2.5 text-xs font-medium uppercase leading-normal text-white shadow-[0_4px_9px_-4px_#3b71ca] transition duration-150 ease-in-out hover:bg-primary-600 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)]">
                        Export</button>
                </div>
            </form>

    </div>
    
    <?php $__env->startPush('script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        $(document).ready(function() {
        $('#sukegiatan_id').select2({
                placeholder: 'Cari Nama Subkegiatan',
                allowClear: true,
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\smilee\resources\views/laporan/bku/index.blade.php ENDPATH**/ ?>