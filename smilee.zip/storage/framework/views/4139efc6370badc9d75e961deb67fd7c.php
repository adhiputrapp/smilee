<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <table class="table-auto">
        <thead>
            <tr>
                <th rowspan="5" class="border border-black">
                    
                </th>
                <th class="text-left border border-black whitespace-nowrap">PEMERINTAH PROVINSI JAWA BARAT</th>
            </tr>
            <tr>
                <th class="text-left border border-black whitespace-nowrap">BIRO UMUM SETDA PROVINSI JAWA BARAT</th>
            </tr>
            <tr>
                <th class="text-left border border-black whitespace-nowrap">TAHUN ANGGARAN <?php echo e($tahun[0]); ?></th>
            </tr>
            <tr>
                <th class="text-left border border-black whitespace-nowrap"></th>
            </tr>
            <tr>
                <th class="text-left border border-black whitespace-nowrap"></th>
            </tr>
            <tr>
                <th colspan="14" class="whitespace-nowrap">LAPORAN PERTANGGUNGJAWABAN BENDAHARA PENGELUARAN PEMBANTU</th>
            </tr>
            <tr>
                <th colspan="14" class="whitespace-nowrap">SPJ Administratif</th>
            </tr>
            <tr>
                <th colspan="14" class="whitespace-nowrap">Bulan : <?php echo e(Carbon\Carbon::now()->month($tahun[1])->locale('id')->monthName); ?> <?php echo e($tahun[0]); ?></th>
            </tr>
            <tr>
                <th colspan="2" class="border border-black text-left whitespace-nowrap">Kuasa Pengguna Anggaran </th>
                <th class="border border-black text-left whitespace-nowrap"> : </th>
            </tr>
            <tr>
                <th colspan="2" class="border border-black text-left whitespace-nowrap">Bendahara Pengeluaran Pembantu</th>
                <th class="border border-black text-left whitespace-nowrap"> : </th>
            </tr>
            <tr>
                <th colspan="2" class="border border-black text-left whitespace-nowrap">Program</th>
                <th class="border border-black text-left whitespace-nowrap"> : <?php echo e($program->kode_program); ?> <?php echo e($program->nama_program); ?></th>
            </tr>
            <tr>
                <th colspan="2" class="border border-black text-left whitespace-nowrap">Kegiatan</th>
                <th class="border border-black text-left whitespace-nowrap"> : <?php echo e($kegiatan->kode_kegiatan); ?> <?php echo e($kegiatan->nama_kegiatan); ?></th>
            </tr>
            <tr>
                <th colspan="2" class="border border-black text-left whitespace-nowrap">Sub Kegiatan</th>
                <th class="border border-black text-left whitespace-nowrap"> : <?php echo e($subKegiatan->kode_sub_kegiatan); ?> <?php echo e($subKegiatan->nama_sub_kegiatan); ?></th>
            </tr>
            <tr>
                <th colspan="2" class="border border-black text-left whitespace-nowrap">Tahun Anggaran </th>
                <th class="border border-black text-left whitespace-nowrap"> : <?php echo e($tahun[0]); ?></th>
            </tr>
            <tr>
                <th colspan="14" class="border border-black text-left whitespace-nowrap"></th>
            </tr>
            <tr>
                <th rowspan="3" class="border border-black">KODE REKENING</th>
                <th rowspan="3" colspan="2" class="border border-black">URAIAN</th>
                <th rowspan="3" class="border border-black">JUMLAH ANGGARAN</th>
                <th colspan="3" class="border border-black">SPJ - LS GAJI</th>
                <th colspan="3" class="border border-black">SPJ - LS BARANG &amp; JASA</th>
                <th colspan="3" class="border border-black">SPJ - UP / GU / TU</th>
                <th rowspan="3" class="border border-black">JUMLAH SPJ (LS+UP+GU+TU) Sd. BULAN INI</th>
                <th rowspan="3" class="border border-black">SISA PAGU ANGGARAN</th>
            </tr>
            <tr>
                <th rowspan="2" class="border border-black">Sd. BULAN LALU</th>
                <th rowspan="2" class="border border-black">BULAN INI</th>
                <th rowspan="2" class="border border-black">Sd. BULAN INI</th>
                <th rowspan="2" class="border border-black">Sd. BULAN LALU</th>
                <th rowspan="2" class="border border-black">BULAN INI</th>
                <th rowspan="2" class="border border-black">Sd. BULAN INI</th>
                <th rowspan="2" class="border border-black">Sd. BULAN LALU</th>
                <th rowspan="2" class="border border-black">BULAN INI</th>
                <th rowspan="2" class="border border-black">Sd. BULAN INI</th>
            </tr>
            <tr>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
            </tr>
            <tr>
                <th class="border border-black">1</th>
                <th colspan="2" class="border border-black">2</th>
                <th class="border border-black">3</th>
                <th class="border border-black">4</th>
                <th class="border border-black">5</th>
                <th class="border border-black">6</th>
                <th class="border border-black">7</th>
                <th class="border border-black">8</th>
                <th class="border border-black">9</th>
                <th class="border border-black">10</th>
                <th class="border border-black">11</th>
                <th class="border border-black">12</th>
                <th class="border border-black">13</th>
                <th class="border border-black">14</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th class="border border-black"></th>
                <th class="border border-black" colspan="2"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th class="border border-black"></th>
                <th class="border border-black" colspan="2"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black">Bandung, <?php echo e(date('d F Y')); ?></th>
                <th class="border border-black"></th>
            </tr>
            <tr>
                <th class="border border-black"></th>
                <th class="border border-black">Disetujui oleh,</th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black">Disiapkan oleh,</th>
                <th class="border border-black"></th>
            </tr>
            <tr>
                <th class="border border-black"></th>
                <th class="border border-black">Kuasa Pengguna Anggaran</th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black"></th>
                <th class="border border-black">Bendahara Pengeluaran Pembantu</th>
                <th class="border border-black"></th>
            </tr>
        </tfoot>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\smilee\resources\views/laporan/spj3/export.blade.php ENDPATH**/ ?>